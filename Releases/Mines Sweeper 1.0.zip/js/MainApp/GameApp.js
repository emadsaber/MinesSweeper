'use strict';

var gameApp = angular.module('gameApp', []);

